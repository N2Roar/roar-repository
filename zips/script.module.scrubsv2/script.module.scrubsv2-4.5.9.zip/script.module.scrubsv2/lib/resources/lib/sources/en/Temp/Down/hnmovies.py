# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-08-2019 by JewBMX in Scrubs.

import re
from resources.lib.modules import client,cleantitle,source_tools
from resources.lib.modules import source_utils,tvmaze


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.genre_filter = ['animation', 'anime']
        self.domains = ['hnmovies.com']
        self.base_link = 'http://hnmovies.com'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.geturl(title)
            url = self.base_link + '/' + mtitle
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = self.base_link + '/' + url + '-' + season + 'x' + episode
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None:
                return sources
            r = getSum.get(url)
            match = getSum.findSum(r)
            for url in match:
                info = source_tools.get_info(url)
                quality = source_tools.get_quality(url)
                valid, host = source_utils.is_host_valid(url, hostDict)
                if valid:
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources


    def resolve(self, url):
        return url

