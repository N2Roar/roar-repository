# plugin.video.dramacool
DramaCool addon for [Kodi](https://kodi.tv/).

Install my [repository](https://github.com/groggyegg/repository.lime/archive/master.zip) to get the latest release.
